echo "# QueueT - Virtual Queue System" > README.md
echo "This is a virtual queue system built with Node.js, Express, and vanilla JavaScript." >> README.md 
